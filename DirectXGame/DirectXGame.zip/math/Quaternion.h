#pragma once
#include "Vector3.h"
#include <cmath>

struct Quaternion final {
	float w, x, y, z;

public:
	// 数式
	Quaternion operator+(const Quaternion& other) const { return Quaternion(w + other.w, x + other.x, y + other.y, z + other.z); }
	Quaternion operator-(const Quaternion& other) const { return Quaternion(w - other.w, x - other.x, y - other.y, z - other.z); }
	Quaternion operator*(float scalar) const { return Quaternion(w * scalar, x * scalar, y * scalar, z * scalar); }
	Vector3 operator*(const Vector3& v) const {
		Vector3 u(x, y, z);
		Vector3 cross1 = Vector3::Cross(u, v);
		Vector3 cross2 = Vector3::Cross(u, cross1);
		return v + cross1 * (2.0f * w) + cross2 * 2.0f;
	}
	Quaternion operator*(const Quaternion& q) const {
		return Quaternion(w * q.w - x * q.x - y * q.y - z * q.z, w * q.x + x * q.w + y * q.z - z * q.y, w * q.y - x * q.z + y * q.w + z * q.x, w * q.z + x * q.y - y * q.x + z * q.w);
	}

	// 归一化四元数
	Quaternion normalize() const {
		float mag = std::sqrt(w * w + x * x + y * y + z * z);
		return Quaternion(w / mag, x / mag, y / mag, z / mag);
	}
	// 将本地旋转变为世界旋转
	Vector3 RotateVector(const Vector3& v) const {
		Quaternion qv(0, v.x, v.y, v.z);
		Quaternion q_conjugate = {w, -x, -y, -z};
		Quaternion result = (*this) * qv * q_conjugate;
		return Vector3(result.x, result.y, result.z);
	}

	// 点积
	static float Dot(const Quaternion& q1, const Quaternion& q2) { return q1.w * q2.w + q1.x * q2.x + q1.y * q2.y + q1.z * q2.z; }
	// Radian to Quaternion(x,y,z)
	static Quaternion RadianToQuaternion(Vector3 rotate) {
		float rx = rotate.x, ry = rotate.y, rz = rotate.z;
		Quaternion qx(cosf(rx / 2), sinf(rx / 2), 0, 0);
		Quaternion qy(cosf(ry / 2), 0, sinf(ry / 2), 0);
		Quaternion qz(cosf(rz / 2), 0, 0, sinf(rz / 2));
		return qx * qy * qz;
	};
	// Slerp插值算法
	static Quaternion Slerp(Quaternion q1, Quaternion q2, float t) {
		q1 = q1.normalize();
		q2 = q2.normalize();
		float dotProduct = Dot(q1, q2);

		// 如果点积为负数，反转其中一个四元数以获得最短路径
		if (dotProduct < 0.0f) {
			q2 = {-q2.w, -q2.x, -q2.y, -q2.z};
			dotProduct = -dotProduct;
		}

		const float THRESHOLD = 0.9995f;
		if (dotProduct > THRESHOLD) {
			// 如果两个四元数非常接近，使用线性插值并归一化结果
			Quaternion result = {q1.w + t * (q2.w - q1.w), q1.x + t * (q2.x - q1.x), q1.y + t * (q2.y - q1.y), q1.z + t * (q2.z - q1.z)};
			return result.normalize();
		}

		// acos and sin for slerp
		float theta_0 = std::acos(dotProduct); // θ₀
		float theta = theta_0 * t;             // θ
		float sin_theta = std::sin(theta);     // sin(θ)
		float sin_theta_0 = std::sin(theta_0); // sin(θ₀)

		float s1 = std::cos(theta) - dotProduct * sin_theta / sin_theta_0;
		float s2 = sin_theta / sin_theta_0;

		return {s1 * q1.w + s2 * q2.w, s1 * q1.x + s2 * q2.x, s1 * q1.y + s2 * q2.y, s1 * q1.z + s2 * q2.z};
	}
	// 指向目标位置的四元数方向向量
	static Quaternion FromDirection(const Vector3& direction, const Vector3& up) {
		Vector3 front = direction;
		front = front.Normalize();
		Vector3 right = Vector3::Cross(up, front).Normalize();
		Vector3 correctedUp = Vector3::Cross(front, right);

		// 通过方向和上向量创建旋转矩阵
		float m00 = right.x;
		float m01 = right.y;
		float m02 = right.z;
		float m10 = correctedUp.x;
		float m11 = correctedUp.y;
		float m12 = correctedUp.z;
		float m20 = front.x;
		float m21 = front.y;
		float m22 = front.z;

		// 将旋转矩阵转换为四元数
		float w = std::sqrt(1.0f + m00 + m11 + m22) / 2.0f;
		float w4 = 4.0f * w;
		float x = (m21 - m12) / w4;
		float y = (m02 - m20) / w4;
		float z = (m10 - m01) / w4;

		return Quaternion(w, x, y, z);
	}
	// 两个四元数的夹角(弧度)
	static float RadianTo(const Quaternion& q1, const Quaternion& q2) {
		// 计算两个四元数的点积
		float dotProduct = Dot(q1, q2);

		// 点积范围可能超出 -1 到 1 的范围，修正以避免 acos 出错
		dotProduct = std::fmax(-1.0f, std::fmin(1.0f, dotProduct));

		// 使用 acos 计算夹角
		return std::acos(dotProduct) * 2.0f; // 结果为弧度
	}
	// 从轴-角度生成四元数
	static Quaternion FromAxisAngle(const Vector3& axis, float angle) {
		float halfAngle = angle / 2.0f;
		float sinHalfAngle = sin(halfAngle);
		return Quaternion(cos(halfAngle), axis.x * sinHalfAngle, axis.y * sinHalfAngle, axis.z * sinHalfAngle);
	}
};